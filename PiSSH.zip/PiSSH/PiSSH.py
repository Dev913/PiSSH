from os import system
import yaml
import paramiko
f=open('Data//Data.yaml')
data=yaml.load(f, Loader=yaml.FullLoader)
ip=data['ip']
port=data['port']
#ip2=data['ip2']
#port2=data['port2']
#ip3=data['ip3']
#port3=data['port3']
#ip4=data['ip4']
#port4=data['port5']
#ip5=data['ip5']
#port5=data['port5']
username=data['username']
password=data['password']
command=data['command']
client = paramiko.SSHClient()
client.load_system_host_keys()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(ip, port=port, username=username, password=password, sock=None)
client.exec_command(command)
